
def celsius(t):
    "[PythonLabs] Convert temperature t from Fahrenheit to Celsius."
    return (t - 32) * 5 / 9

    
